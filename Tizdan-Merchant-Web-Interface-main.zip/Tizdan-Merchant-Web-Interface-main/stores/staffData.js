const cards = [
    {
        img: 'img/staff1.png',
        first_name: 'Tiana',
        last_name: 'Siphron',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff2.png',
        first_name: 'Marilyn',
        last_name: 'Franci',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff3.png',
        first_name: 'Marcus',
        last_name: 'Lubin',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff2.png',
        first_name: 'Marilyn',
        last_name: 'Franci',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff3.png',
        first_name: 'Marcus',
        last_name: 'Lubin',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff1.png',
        first_name: 'Tiana',
        last_name: 'Siphron',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff2.png',
        first_name: 'Marilyn',
        last_name: 'Franci',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff3.png',
        first_name: 'Marcus',
        last_name: 'Lubin',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff2.png',
        first_name: 'Marilyn',
        last_name: 'Franci',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff3.png',
        first_name: 'Marcus',
        last_name: 'Lubin',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff2.png',
        first_name: 'Marilyn',
        last_name: 'Franci',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
    {
        img: 'img/staff3.png',
        first_name: 'Marcus',
        last_name: 'Lubin',
        role: 'Merchant',
        email: 'Chance.lu@gmail.com',
        phone: '+ 218 21 1234567'
    },
]

export default cards