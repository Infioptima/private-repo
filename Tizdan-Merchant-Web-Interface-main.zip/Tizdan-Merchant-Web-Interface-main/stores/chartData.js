const data = [  
    {name: 'Feb 25', amount: 400}, 
    {name: 'Feb 26', amount: 500},
    {name: 'Feb 27', amount: 300},
    {name: 'Feb 28', amount: 400},
    {name: 'Feb 29', amount: 600},
    {name: 'Mar 1', amount: 200},
    {name: 'Mar 2', amount: 300}
];

export default data