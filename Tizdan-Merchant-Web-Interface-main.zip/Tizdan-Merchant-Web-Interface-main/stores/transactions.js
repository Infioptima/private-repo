let transactions = [
    {
        id:'PATX1000456',
        sender: {name:'Company 1', role: 'Merchant', icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000457',
        sender: {name:'Company test', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Best company', role: 'Merchant', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000458',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000459',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000460',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000466',
        sender: {name:'Company 1', role: 'Merchant', icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000467',
        sender: {name:'Company test', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Best company', role: 'Merchant', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000468',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000469',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    },
    {
        id:'PATX1000470',
        sender: {name:'Company 1', role: 'Merchant',icon: 'img/user-icon.png'},
        receiver: {name: 'Alan Aliev', role: 'Customer', icon: 'img/user-icon.png'},
        amount: 'LYD 100',
        status: 'Completed',
        date: 'Mar 03, 2021 - 07:43 PM'
    }
]

export default transactions