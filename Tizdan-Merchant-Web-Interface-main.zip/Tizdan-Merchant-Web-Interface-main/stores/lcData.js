const entries = [
    {
        id: '3451',
        user_name: 'Lincoln Ekstrom Bothman',
        company: 'Libyan international company',
        phone: '+971 2 1234567',
        value: 'LYD 100',
        status: 'CBL Approved, awaiting SWIFT',
        status_id:5,
        date:'5/02/20'
    },
    {
        id: '3452',
        user_name: 'Livia Rhiel Madsen',
        company: 'SABIC',
        phone: '+971 2 1234567',
        value: 'LYD 500',
        status: 'Declined, more info required',
        status_id:3,
        date:'12/03/25'
    },
    {
        id: '3453',
        user_name: 'Randy Curtis',
        company: 'QNB Group',
        phone: '+971 2 1234567',
        value: 'LYD 200',
        status: 'Approved, sent to CBL',
        status_id:2,
        date:'2/03/21'
    },
    {
        id: '3443',
        user_name: 'Rayna Gouse',
        company: 'First Abu Dhabi Bank',
        phone: '+971 2 1234567',
        value: 'LYD 1200',
        status: 'Awaiting Internal Review and Approval',
        status_id:1,
        date:'29/11/24'
    },
    {
        id: '3461',
        user_name: 'Lincoln Ekstrom Bothman',
        company: 'Libyan international company',
        phone: '+971 2 1234567',
        value: 'LYD 100',
        status: 'CBL Approved, awaiting SWIFT',
        status_id:5,
        date:'5/02/20'
    },
    {
        id: '3462',
        user_name: 'Livia Rhiel Madsen',
        company: 'SABIC',
        phone: '+971 2 1234567',
        value: 'LYD 500',
        status: 'Declined, more info required',
        status_id:3,
        date:'12/03/25'
    },
    {
        id: '3463',
        user_name: 'Randy Curtis',
        company: 'QNB Group',
        phone: '+971 2 1234567',
        value: 'LYD 200',
        status: 'Approved, sent to CBL',
        status_id:2,
        date:'2/03/21'
    },
    {
        id: '3464',
        user_name: 'Rayna Gouse',
        company: 'First Abu Dhabi Bank',
        phone: '+971 2 1234567',
        value: 'LYD 1200',
        status: 'Awaiting Internal Review and Approval',
        status_id:1,
        date:'29/11/24'
    },
    {
        id: '3471',
        user_name: 'Lincoln Ekstrom Bothman',
        company: 'Libyan international company',
        phone: '+971 2 1234567',
        value: 'LYD 100',
        status: 'CBL Approved, awaiting SWIFT',
        status_id:5,
        date:'5/02/20'
    },
    {
        id: '3472',
        user_name: 'Livia Rhiel Madsen',
        company: 'SABIC',
        phone: '+971 2 1234567',
        value: 'LYD 500',
        status: 'Declined, more info required',
        status_id:3,
        date:'12/03/25'
    },
    {
        id: '3473',
        user_name: 'Randy Curtis',
        company: 'QNB Group',
        phone: '+971 2 1234567',
        value: 'LYD 200',
        status: 'Approved, sent to CBL',
        status_id:2,
        date:'2/03/21'
    },
    {
        id: '3475',
        user_name: 'Rayna Gouse',
        company: 'First Abu Dhabi Bank',
        phone: '+971 2 1234567',
        value: 'LYD 1200',
        status: 'Awaiting Internal Review and Approval',
        status_id:1,
        date:'29/11/24'
    },

]

export default entries
