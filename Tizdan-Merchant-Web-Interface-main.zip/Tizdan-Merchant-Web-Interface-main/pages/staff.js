import FiltersPanel from "../components/common/FiltersPanel"
import SearchFilter from "../components/common/SearchFilter"
import Select from "../components/common/Select"
import Layout from "../components/layout/Layout"
import AddEmployeePopup from "../components/popup/AddEmployee"
import Card from "../components/staff/Card"
import cards from "../stores/staffData"

let sortBySelect = {
    items: [
        {
            value: '1',
            title: 'item 1'
        },
        {
            value: '2',
            title: 'item 2'
        },
        {
            value: '3',
            title: 'item 3'
        }
    ],
    value: '',
    label: 'Sort By'
}

let rolesSelect = {
    items: [
        {
            value: '1',
            title: 'role 1'
        },
        {
            value: '2',
            title: 'role 2'
        },
        {
            value: '3',
            title: 'role 3'
        }
    ],
    value: '',
    label: 'Roles'
}

export default function Staff() {
    return (
        
        <Layout>
            <div className="row staff white-box">
                <div className="filters-row">
                    <FiltersPanel>
                        <div className="search">
                            <SearchFilter placeholder="Search by name, phone, company"></SearchFilter>
                        </div>
                        <div className="dropdowns">
                            <Select data={rolesSelect}></Select>
                            <Select data={sortBySelect}></Select>
                            <div className="add-btn"><AddEmployeePopup /></div> 
                        </div>
                    </FiltersPanel>
                </div>
                <div className="cards">
                    {cards.map((card, index) => (
                        <Card key={index} data={card} />
                    ))}
                </div>
            </div>
            
            <style jsx>{`
                .staff {
                    width: 100%;
                    min-height: 950px;
                    padding: 30px 35px 0 35px;                 
                }
                .search {
                    width:469px;
                }
                .filters-row {
                    height: 70px;
                }
                .dropdowns {
                    margin-top: -13px;
                    display:flex;
                }
                .cards {
                    margin-left:-1.5%;
                }
                .add-btn {
                    margin:13px 0 0 20px;
                }
                
            `}</style>
        </Layout>
    );
}
