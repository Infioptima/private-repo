import Layout from '../components/layout/Layout'

export default function Profile() {
  return (
    <Layout>
      <div><h1>Profile page</h1></div>
    </Layout>
  )
}