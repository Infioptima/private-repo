import FiltersPanel from "../components/common/FiltersPanel"
import SearchFilter from "../components/common/SearchFilter"
import Select from "../components/common/Select"
import Layout from "../components/layout/Layout"
import LcTable from "../components/lc/LcTable"
import AddLcPopup from "../components/popup/AddLc"

let statusSelect = {
    items: [
        {
            value: '1',
            title: 'status 1'
        },
        {
            value: '2',
            title: 'status 2'
        },
        {
            value: '3',
            title: 'status 3'
        }
    ],
    value: '',
    label: 'Status'
}

export default function Lc() {
    return (
        
        <Layout>
            <div className="row lc white-box">
                <div className="filters-row">
                    <FiltersPanel>
                        <div className="search">
                            <SearchFilter placeholder="Search by name, phone, company"></SearchFilter>
                        </div>
                        <div className="dropdowns">
                            <Select data={statusSelect}></Select>
                            <div className="add-btn"><AddLcPopup /></div> 
                        </div>
                    </FiltersPanel>
                </div>
                <div className="row lc-list">
                    <LcTable></LcTable>
                </div>
            </div>
            
            <style jsx>{`
                .lc {
                    width: 100%;
                    min-height: 950px;
                    padding: 30px 35px 0 35px;                 
                }
                .search {
                    width:469px;
                }
                .filters-row {
                    height: 70px;
                }
                .dropdowns {
                    margin-top: -13px;
                    display:flex;
                }
                .add-btn {
                    margin:13px 0 0 20px;
                }
                
            `}</style>
        </Layout>
    );
}
