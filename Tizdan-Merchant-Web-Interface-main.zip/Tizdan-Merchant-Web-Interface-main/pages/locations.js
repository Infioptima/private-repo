import SearchFilter from '../components/common/SearchFilter'
import Select from '../components/common/Select'
import Layout from '../components/layout/Layout'
import Card from '../components/locations/Card'
import AddLocationPopup from '../components/popup/AddLocation'
import dynamic from 'next/dynamic'

const MapNoSSR = dynamic(
  () => import('../components/locations/Map'),
  {  loading: () => <p>Loading ...</p>, ssr: false }
)

let sortBySelect = {
    items: [
        {
            value: '1',
            title: 'item 1'
        },
        {
            value: '2',
            title: 'item 2'
        },
        {
            value: '3',
            title: 'item 3'
        }
    ],
    value: '',
    label: 'Sort By'
}

let rolesSelect = {
    items: [
        {
            value: '1',
            title: 'role 1'
        },
        {
            value: '2',
            title: 'role 2'
        },
        {
            value: '3',
            title: 'role 3'
        }
    ],
    value: '',
    label: 'Roles'
}

let locations = [
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},
    {title:'Sidi Al-Marghani', address:'Tripoli, Libya'},

]

export default function Locations() {
    return (
        <div>
            <Layout>
                <div className="row locations white-box">
                    <div className="list-wrap">
                        <div className="filters-row">
                            <div className="search-wrap">
                                <div className="search">
                                    <SearchFilter placeholder="Search by name, phone, company"></SearchFilter>
                                </div>
                                <div className="add-btn"><AddLocationPopup /></div>
                            </div>
                            <div className="dropdowns">
                                <Select data={rolesSelect}></Select>
                                <Select data={sortBySelect}></Select>
                            </div>
                        </div>
                        <div className="list">
                            {locations.map((location, index) => (
                                <Card key={index} data={location} />
                            ))}
                        </div>   
                    </div>
                    <MapNoSSR />
                </div>
                <style jsx>{`
                    .list-wrap {
                        width:500px;
                        min-height:600px;
                    }
                    .locations {
                        padding:20px;
                        min-height:950px;
                        display:flex;
                    }
                    .search {
                        width:calc(100% - 55px);
                    }
                    .add-btn {

                    }
                    .search-wrap, .dropdowns {
                        display:flex;
                        justify-content: space-between;
                        margin-bottom: 7px;
                    }
                    .dropdowns {
                        margin-left:-25px;
                    }
                    .list {
                        max-height:800px;
                        overflow-y:auto;
                        padding: 5px 3px 0 3px;
                        margin-top:15px;
                    }
                    .map {
                        width:calc(100% - 520px);
                        min-height:700px;
                        margin-left:20px;
                    }
                `}</style>            
            </Layout>
        </div>

    )
}