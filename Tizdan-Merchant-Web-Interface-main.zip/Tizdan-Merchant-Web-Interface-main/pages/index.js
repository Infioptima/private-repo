import Chart from "../components/dashboard/Chart";
import ChartFilters from "../components/dashboard/ChartFilters";
import StatBlock from "../components/dashboard/StatBlock";
import TransactionsTable from "../components/dashboard/TransactionsTable";
import Layout from "../components/layout/Layout";

export default function Dashboard() {
    return (
        <Layout>
            <div className="row">
                <div className="stats">
                    <StatBlock
                        class="current-balance"
                        title="Current Balance"
                        value="1,370"
                        currency="LYD"
                    ></StatBlock>
                    <StatBlock
                        class="available-balance"
                        title="Available balance"
                        value="1,250"
                        currency="LYD"
                    ></StatBlock>
                    <StatBlock
                        class="daily-sales"
                        title="Daily Sales"
                        value="1,023"
                        currency="LYD"
                    ></StatBlock>
                </div>
                <div className="chart-wrap">
                    <h2>Sales Summary</h2>
                    <ChartFilters></ChartFilters>
                    <div className="chart">
                        <Chart></Chart>
                    </div>
                </div>
            </div>

            <div className="row transactions">
                <TransactionsTable></TransactionsTable>
            </div>
            
            <style jsx>{`
                .stats {
                    float:left;
                    width:392px;
                }
                .chart-wrap {
                    width:calc(100% - 415px);
                    float:left;
                    height:418px;
                    background:#fff;
                    margin-left:20px;
                    box-shadow: 0px 4px 4px #D7DCE8;
                    border-radius: 10px;
                }
                .chart {
                    clear:both;
                    width: 100%;
                    height: 100%;
                }
                .transactions {
                    clear:both;
                }
                h2 {
                    padding:30px 35px 25px 30px;
                    float:left;
                }
            `}</style>
        </Layout>
    );
}
