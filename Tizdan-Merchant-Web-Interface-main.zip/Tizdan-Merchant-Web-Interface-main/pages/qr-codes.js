import Layout from '../components/layout/Layout'

export default function Qrcodes() {
  return (
    <Layout>
      <div><h1>Qr codes page</h1></div>
    </Layout>
  )
}