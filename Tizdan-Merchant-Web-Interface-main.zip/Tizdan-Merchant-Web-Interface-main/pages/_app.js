import "../styles/reset.css";
import "../styles/globals.css";
import "../styles/layout.css";
import { ThemeProvider, createMuiTheme} from '@material-ui/core/styles';
import NoSsr from "../components/common/NoSsr";

const theme = createMuiTheme({
    typography: {
      fontFamily: [
        'Lato',
        '-apple-system',
        'Roboto',
      ].join(','),
    },
});

function MyApp({ Component, pageProps }) {
    return (
        <NoSsr>
            <ThemeProvider theme={theme}>
                <Component {...pageProps} />
            </ThemeProvider>
        </NoSsr>
    );
}

export default MyApp;
