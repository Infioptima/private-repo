import Layout from '../components/layout/Layout'

export default function Payouts() {
  return (
    <Layout>
      <div><h1>Payouts page</h1></div>
    </Layout>
  )
}