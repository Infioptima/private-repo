import Layout from "../components/layout/Layout";
import TransactionsTable from "../components/transactions/TransactionsTable";
import FiltersPanel from "../components/common/FiltersPanel";
import SearchFilter from "../components/common/SearchFilter";
import Select from "../components/common/Select";
import DatePicker from "../components/common/DatePicker";

let transactionSelect = {
    items: [
        {
            value: 'm-m',
            title: 'merchant => merchant'
        },
        {
            value: 'm-c',
            title: 'merchant => customer'
        }
    ],
    value: '',
    label: 'Transaction Type'
}

let locationsSelect = {
    items: [
        {
            value: '1',
            title: '33 Road avenue, Nyc'
        },
        {
            value: '2',
            title: 'Nauki 11/13, Kharkov'
        },
        {
            value: '3',
            title: 'Broadway 183, Nyc'
        }
    ],
    value: '',
    label: 'Location'
}

let employeeSelect = {
    items: [
        {
            value: '1',
            title: 'Employee 1'
        },
        {
            value: '2',
            title: 'Employee 2'
        },
        {
            value: '3',
            title: 'Employee 3'
        }
    ],
    value: '',
    label: 'Employee'
}

let statusSelect = {
    items: [
        {
            value: '1',
            title: 'completed'
        },
        {
            value: '2',
            title: 'incomplete'
        }
    ],
    value: '',
    label: 'Status'
}

export default function Transactions() {
    return (
        <Layout>
            <div className="row transactions">
                <TransactionsTable>
                    <div className="filters-row">
                        <FiltersPanel>
                            <div className="search">
                                <SearchFilter placeholder="Search by name, phone, company"></SearchFilter>
                            </div> 
                            <div className="dropdowns">
                                <Select data={transactionSelect}></Select>
                                <Select data={locationsSelect}></Select>
                                <Select data={employeeSelect}></Select>
                                <Select data={statusSelect}></Select>
                                <div className="date">
                                    <DatePicker label="Select date" />
                                </div>
                            </div>
                        </FiltersPanel>
                    </div>
                </TransactionsTable>
            </div>
            <style jsx>{`
                .filters-row {
                    height:70px;
                }
                .search {
                    width:469px;
                }
                .dropdowns {
                    margin-top:-17px;
                    display: flex;
                    align-items: center;
                }
                .date {
                    display:inline-block;
                    margin-left: 20px;
                    width: 100%;
                    margin-top: -8px;
                }
            `}</style>
        </Layout>
    );
}
