import React from "react"
import MuiButton from "@material-ui/core/Button"
import MuiDialog from "@material-ui/core/Dialog"
import MuiDialogActions from "@material-ui/core/DialogActions"
import MuiDialogContent from "@material-ui/core/DialogContent"
import MuiDialogTitle from "@material-ui/core/DialogTitle"
import IconButton from '@material-ui/core/IconButton'
import CloseIcon from '@material-ui/icons/Close'
import Typography from '@material-ui/core/Typography'
import { withStyles, makeStyles} from '@material-ui/core/styles'


const useStyles = makeStyles((theme) => ({
    submitBtn: {
        background:'#FF815D',
        '&:hover': {
            background: "#f5734e",
        },
        color:'#fff',
    },
    cancelBtn: {
        border:'1px solid #252340',
    }
}));

const styles = (theme) => ({
    root: {
        padding:0,
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500],
    },

});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding:0,
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        padding:"50px 0 0 0",
        justifyContent: 'space-between'
    },
}))(MuiDialogActions);

const Dialog = withStyles((theme) => ({
    paper: {
        width:530,
        padding:'50px 60px 60px 60px',
    },
}))(MuiDialog);

const Button = withStyles((theme) => ({
    root: {
        textTransform:'capitalize',
        width:190,
        height:40,
        fontSize:18,
        borderRadius:10
    },
}))(MuiButton);


export default function AddLcPopup() {
    const classes = useStyles()
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (   
        <div>
            <div className="add-btn" onClick={handleClickOpen} title="New Letter of credit">+</div>
            <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title" onClose={handleClose}>New letter of credit</DialogTitle>
                <DialogContent>
                    
                </DialogContent>
                <DialogActions>

                </DialogActions>
            </Dialog>
            <style jsx>{`
                .add-btn {
                    width: 40px;
                    height: 40px;
                    background: #FF815D;
                    border-radius: 10px;
                    line-height: 38px;
                    text-align: center;
                    color: white;
                    font-size: 20px;
                    font-weight: bold;
                    cursor:pointer;
                }
            `}</style>
        </div>
    );
}
