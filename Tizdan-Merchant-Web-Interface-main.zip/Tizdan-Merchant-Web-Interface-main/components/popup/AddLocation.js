import React from "react";
import MuiButton from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import MuiDialog from "@material-ui/core/Dialog";
import MuiDialogActions from "@material-ui/core/DialogActions";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import Select from "../common/Select";
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import { withStyles, makeStyles} from '@material-ui/core/styles';

let category = {
    items: [
        {
            value: '1',
            title: 'Category name 1'
        },
        {
            value: '2',
            title: 'Category name 2'
        },
        {
            value: '3',
            title: 'Category name 3'
        }
    ],
    value: '',
    label: 'Merchant category code'
}

let countries = {
    items: [
        {
            value: '1',
            title: 'Country 1'
        },
        {
            value: '2',
            title: 'Country 2'
        },
    ],
    value: '',
    label: 'Country'
}

const useStyles = makeStyles((theme) => ({
    submitBtn: {
        background:'#FF815D',
        '&:hover': {
            background: "#f5734e",
        },
        color:'#fff',
    },
    cancelBtn: {
        border:'1px solid #252340',
    }
}));

const styles = (theme) => ({
    root: {
        padding:0,
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500],
    },

});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding:0,
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        padding:"50px 0 0 0",
        justifyContent: 'space-between'
    },
}))(MuiDialogActions);

const Dialog = withStyles((theme) => ({
    paper: {
        width:530,
        padding:'50px 60px 60px 60px',
    },
}))(MuiDialog);

const Button = withStyles((theme) => ({
    root: {
        textTransform:'capitalize',
        width:190,
        height:40,
        fontSize:18,
        borderRadius:10
    },
}))(MuiButton);


export default function AddLocationPopup() {
    const classes = useStyles()
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (   
        <div>
            <div className="add-btn" onClick={handleClickOpen} title="Add location">+</div>
            <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title" onClose={handleClose}>Add Location</DialogTitle>
                <DialogContent>
                    <TextField margin="dense" id="name" label="Name" type="text" fullWidth/>
                    <div className="dropdowns">
                        <div>
                            <Select data={category}></Select>
                        </div>
                        <div>
                            <Select data={countries}></Select>
                        </div>                        
                    </div>
                    <TextField margin="dense" id="address" label="Address line" type="text" fullWidth />
                    <div className="group">
                        <TextField margin="dense" id="state" label="State" type="text" />                    
                        <TextField margin="dense" id="postal" label="Postal code" type="text" />
                    </div>
                    <div className="group">
                        <TextField margin="dense" id="city" label="City" type="text" />                    
                        <TextField margin="dense" id="city_localized" label="City localized" type="text" />
                    </div>                    
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} className={classes.cancelBtn}>Cancel</Button>
                    <Button onClick={handleClose} className={classes.submitBtn}>Create account</Button>
                </DialogActions>
            </Dialog>
            <style jsx>{`
                .add-btn {
                    width: 40px;
                    height: 40px;
                    background: #FF815D;
                    border-radius: 10px;
                    line-height: 38px;
                    text-align: center;
                    color: white;
                    font-size: 20px;
                    font-weight: bold;
                    cursor:pointer;
                }
                .group {
                    display:flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .create-btn {
                    background:#fff;
                }
                .dropdowns {
                    margin-left:-30px;
                    width:100%;
                }
                .dropdowns > div {
                    margin-top:5px;
                }
            `}</style>
        </div>
    );
}
