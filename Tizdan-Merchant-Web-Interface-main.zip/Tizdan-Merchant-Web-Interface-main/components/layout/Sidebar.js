import Navigation from "./Navigation";

const Sidebar = (props) => {
    return (
        <div id="sideBar">
            <div className="logo">
                <a href="/">
                    <img src="/img/tizdan-logo.png" width={154} height={30} />
                </a>
            </div>

            <Navigation page={props.page} />

            <style jsx>{`
                .logo {
                    top: 25px;
                    position: relative;
                    left: 35px;
                }
            `}</style>
            <style global jsx>{``}</style>
        </div>
    );
}
export default Sidebar