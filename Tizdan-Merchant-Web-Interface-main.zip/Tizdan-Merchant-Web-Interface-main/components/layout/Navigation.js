import Link from 'next/link'
import { useRouter } from 'next/router'

const Navigation = () => {

    const router = useRouter()
    let page = router.asPath.split('/')[1]
    page = page || 'dashboard'

    return (
        <nav className="" role="navigation">
            <ul>
                <Link href="/">
                    <a>
                        <li className={page === "dashboard" ? "active" : ""}>
                            <span className="icon dashboard"></span> 
                            Dashboard
                        </li>
                    </a>
                </Link>
                <Link href="/transactions">
                    <a>
                        <li className={page === "transactions" ? "active" : ""}>
                            <span className="icon transactions"></span>
                            Transactions
                        </li>
                    </a>
                </Link>
                <Link href="/payouts">
                    <a>
                        <li className={page === "payouts" ? "active" : ""}>
                            <span className="icon payouts"></span>
                            Payouts
                        </li>
                    </a>
                </Link>
                <Link href="/staff">
                    <a>
                        <li className={page === "staff" ? "active" : ""}>
                            <span className="icon staff"></span>
                            Staff
                        </li>
                    </a>
                </Link>
                <Link href="/locations">
                    <a>
                        <li className={page === "locations" ? "active" : ""}>
                            <span className="icon locations"></span>
                            Locations
                        </li>
                    </a>
                </Link>
                <Link href="/qr-codes">
                    <a>
                        <li className={page === "qr-codes" ? "active" : ""}>
                            <span className="icon qr-codes"></span>
                            QR Codes
                        </li>
                    </a>
                </Link>
                <Link href="/profile">
                    <a>
                        <li className={page === "profile" ? "active" : ""}>
                            <span className="icon profile"></span>
                            Profile/KYC
                        </li>
                    </a>
                </Link>
                <Link href="/lc">
                    <a>
                        <li className={page === "lc" ? "active" : ""}>
                            <span className="icon lc"></span>
                            Letter Of Credit
                        </li>
                    </a>
                </Link>
            </ul>

            <style jsx>{`
                li {
                    height: 60px;
                    width: 278px;
                    font-size: 18px;
                    color: #fff;
                    list-style-type: none;
                    line-height: 60px;
                    background-position: 33px 19px;
                    background-repeat: no-repeat;
                    margin-left: -3px;
                    padding-left: 31px;
                    border-top-right-radius: 5px;
                    border-bottom-right-radius: 5px;
                }

                li:hover .icon {
                    margin-left:2px;
                }

                ul {
                    position: relative;
                    top: 56px;
                    padding-left: 4px;
                }

                .active {
                    background-color: #f0f3f9;
                    color: #252340;
                    font-weight:900;
                }

                li.active .icon {
                    margin-left:2px;
                }

                .icon {
                    width: 24px;
                    height: 24px;
                    display: inline-block;
                    vertical-align: middle;
                    background-size: 192px 48px;
                    background-image: url(img/sidebar-icons-sprite.png);
                    margin-right: 27px;
                }

                .dashboard {
                    background-position: 0px 0px;
                }
                .active .dashboard {
                    background-position: 0px 24px;
                }

                .transactions {
                    background-position: -24px 0px;
                }
                .active .transactions {
                    background-position: -24px 24px;
                }

                .payouts {
                    background-position: -48px 0px;
                }
                .active .payouts {
                    background-position: -48px 24px;
                }

                .staff {
                    background-position: -72px 0px;
                }
                .active .staff {
                    background-position: -72px 24px;
                }

                .locations {
                    background-position: -96px 0px;
                }
                .active .locations {
                    background-position: -96px 24px;
                }

                .qr-codes {
                    background-position: -120px 0px;
                }
                .active .qr-codes {
                    background-position: -120px 24px;
                }

                .profile {
                    background-position: -144px 0px;
                }
                .active .profile {
                    background-position: -144px 24px;
                }

                .lc {
                    background-position: -168px 0px;
                }
                .active .lc {
                    background-position: -168px 24px;
                }
            `}</style>
        </nav>
    )

}
   
export default Navigation