import Head from "next/head";
import Sidebar from "./Sidebar";
import Searchbar from "./Searchbar";

const Layout = ({ children, title = "Tizdan merchant" }) => {

    return (
        <div>
            <Head>
                <title>{title}</title>
                <meta charSet="utf-8" />
                <meta
                    name="viewport"
                    content="initial-scale=1.0, width=device-width"
                />
            </Head>
            <div id="mainContainer">
                <Sidebar />
                <div id="content">
                    <Searchbar />
                    <div className="main-content">
                        {children}
                    </div>
                </div>
            </div>
            <link rel="preconnect" href="https://fonts.gstatic.com" />
            <link
                href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap"
                rel="stylesheet"
            />
        </div>
    );
}

export default Layout
