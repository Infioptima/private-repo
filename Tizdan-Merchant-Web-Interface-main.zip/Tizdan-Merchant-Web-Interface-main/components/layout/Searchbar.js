import Link from 'next/link'

const Searchbar = (props) => {
    return ( 
        <div id="search">
            <input type="text" name="search" className="search-input white-box" />
            <div className="search-icon icon"></div>
            <Link href="/settings">
                <a>
                    <div className="settings-icon icon"></div>
                </a>
            </Link>
            <Link href="/logout">
                <a>
                    <div className="logout-icon icon"></div>
                </a>
            </Link>            
            <div className="profile-icon"><img src="img/user-icon.png" /></div>

            <style jsx>{`
                input[type=text] {
                    width: 100%;
                    position: relative;
                    height:68px;
                    border:none;
                    font-size: 25px;
                    padding: 0 80px;
                }

                .icon {
                    width:20px;
                    height:20px;
                    position:absolute;
                    background-size: 62px 21px;
                    background-image: url(img/search-bar-icons.png);
                }

                .search-icon {
                    left:35px;
                    top:24px;
                    width:19px;
                }

                .settings-icon {
                    right:135px;
                    top:24px;
                    height: 21px;
                    background-position: -20px 0px;
                }

                .logout-icon {
                    right:95px;
                    top:24px;
                    width:22px;
                    background-position: -40px 0px;
                }

                .profile-icon {
                    width:40px;
                    height:40px;
                    position:absolute;
                    top:14px;
                    right:35px;
                }

                .profile-icon img {
                    width:40px;
                    height:40px;
                    border-radius:50%;
                }
            `}</style>
        </div>    
    );
}
 
export default Searchbar;