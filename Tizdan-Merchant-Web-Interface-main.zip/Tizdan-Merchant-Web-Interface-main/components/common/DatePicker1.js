
import React from "react";
import { DateRange } from 'react-date-range';

const DatePicker1 = (props) => {
    const [state, setState] = React.useState([
        {
            startDate: new Date(),
            endDate: null,
            key: "selection",
        },
    ]);

    return (
        <DateRange
            editableDateInputs={true}
            onChange={(item) => setState([item.selection])}
            moveRangeOnFirstSelection={false}
            ranges={state}
        />
    );
};

export default DatePicker1;