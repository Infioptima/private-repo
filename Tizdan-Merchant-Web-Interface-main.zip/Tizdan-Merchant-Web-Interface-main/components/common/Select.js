import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select1 from '@material-ui/core/Select';
import React from 'react';

const useStyles = makeStyles((theme) => ({
    formControl: {
        minWidth: 150,
        width:'100%',
    }
}));

const Select = (props) => {
    const classes = useStyles();
    const [value, setValue] = React.useState(props.data.value);
  
    const handleChange = (event) => {
      setValue(event.target.value);
    };
    return ( 
        <div className="select">
            <FormControl className={classes.formControl}>
                <InputLabel id="select-label">{props.data.label}</InputLabel>
                <Select1 labelId="select-label" value={value} onChange={handleChange} >
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>
                    {props.data.items.map((item, index) => (
                        <MenuItem key={index} value={item.value}>{item.title}</MenuItem>
                    ))}
                </Select1>
            </FormControl>
            <style jsx>{`
                .select {
                    display: inline-block;
                    margin-left:30px;
                    width:100%;  
                }
            `}</style>
        </div>
    );
}
 
export default Select;