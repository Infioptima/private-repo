const FiltersPanel = (props) => {
    return ( 
        <div className="filters row">
            {props.children}

            <style jsx>{`
                .filters {
                    overflow:visible;
                    display: flex;
                    justify-content: space-between;
                }
            `}</style>
        </div>
    );
}
 
export default FiltersPanel;