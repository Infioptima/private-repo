const SearchFilter = (props) => {
    return ( 
        <div className="search-filter">
            <input type="text" name="search-text" placeholder={props.placeholder}/>
            <style jsx>{`
                input[type=text] {
                    width: 100%;
                    height: 40px;
                    background: #F8F8F8;
                    border-radius: 10px;
                    border:none;
                    padding:0 0 0 50px;
                    background-image:url(/img/search-icon.png);
                    background-position:15px 11px;
                    background-repeat:no-repeat;
                    background-size: 18px 18px;
                    font-size: 14px;
                }
            `}</style>
        </div>
    );
}
 
export default SearchFilter;