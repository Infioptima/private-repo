import Link from "next/link"
import entries from "../../stores/lcData"
import LcRow from "./LcRow"

const LcTable = (props) => {
    return (
        <div className="lc-table">

            <div className="row table-head">
                <span className="w20">User name</span>
                <span className="w20">Company</span>
                <span className="w20">Phone</span>
                <span className="w10">Value</span>
                <span className="w20">status</span>
                <span className="w10 date">expiration date</span>
            </div>
            <div className="table">
                {entries.map((entry) =>    
                    
                    <Link href="#">
                        <LcRow data={entry} key={entry.id}></LcRow>
                    </Link>                  
                )}
            </div>

            <style jsx>{`
                .lc-table {
                    min-height: 814px;
                }
                .table-head {
                    font-weight: 600;
                    font-size: 14px;
                    line-height: 17px;
                    text-transform: uppercase;
                    color: #7e889f;
                    padding: 15px 20px 10px 20px;
                }
                .table-head span {
                    display: inline-block;
                }
                .table {
                    width: 100%;
                    border-top: 1px solid #e8e9ec;
                }
                .date {
                    text-align: right;
                }
            `}</style>
        </div>
    )
}
 
export default LcTable