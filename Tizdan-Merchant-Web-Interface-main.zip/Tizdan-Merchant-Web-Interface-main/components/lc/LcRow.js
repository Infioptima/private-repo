const LcRow = (props) => {
    return ( 
        <div className="lc-row row">
            <div className="w20">
                <div className="user-name">{props.data.user_name}</div>
            </div>
            <div className="w20">
                <div className="company">{props.data.company}</div>
            </div>
            <div className="w20">
                <div className="phone">{props.data.phone}</div>
            </div>
            <div className="w10">
                <div className="value">{props.data.value}</div>
            </div>
            <div className="w20">
                <div className="status">{props.data.status}</div>
            </div>
            <div className="w10 date">
                <div>{props.data.date}</div>
            </div>

            <style jsx>{`
                .lc-row {
                    font-size:16px;
                    padding:20px;
                    border-bottom: 1px solid #E8E9EC;
                }
                .lc-row>div {
                    display:inline-block;
                    vertical-align: middle;
                }
                .lc-row:nth-child(odd) {
                    background-color: #FBFCFF;
                }
                .date {
                    text-align:right;
                }
            `}</style>
        </div>
    );
}
 
export default LcRow;