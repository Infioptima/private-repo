import {Loader, LoaderOptions} from 'google-maps'

const loader = new Loader('AIzaSyC-8vJ5UC_JBrwWVp4imilysvKyA-PCuuU', {});

const Map = (props) => {
    loader.load().then(function (google) {
        const map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 30.686989, lng: 16.836794},
            zoom: 7,
        });
    });
    return ( 
        <div className="map" id="map">
            <style jsx>{`
                #map {
                    width:calc(100% - 520px);
                    min-height:700px;
                    margin-left:20px;
                }
            `}</style> 
        </div>
     );
}
 
export default Map;