const Card = (props) => {
    return ( 
        <div className="card white-box">
            <h3>{props.data.title}</h3>
            <span className="address">{props.data.address}</span>
            <style jsx>{`
                .card {
                    background: #FBFCFF;
                    padding:27px 25px;
                    margin-bottom:15px;
                }
            `}</style> 
        </div>
    );
}
 
export default Card;