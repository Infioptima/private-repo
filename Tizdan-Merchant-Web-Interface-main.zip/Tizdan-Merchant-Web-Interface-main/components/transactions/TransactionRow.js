import { useState } from "react";

const TransactionRow = (props) => {

    const [expand,setExpand]=useState(false);

    return (
        <div className="transaction-row row" onClick={() => { setExpand(!expand) }} >
            <div className="w30">
                <img src={props.data.sender.icon} className="img" />
                <div className="user-name">{props.data.sender.name}</div>
                <div className="role">{props.data.sender.role}</div>
            </div>
            <div className="w30">
                <img src={props.data.receiver.icon} className="img" />
                <div className="user-name">{props.data.receiver.name}</div>
                <div className="role">{props.data.receiver.role}</div>
            </div>
            <div className="w10">
                <div className="status">{props.data.status}</div>
            </div>
            <div className="w10">
                <div className="amount">{props.data.amount}</div>
            </div>
            <div className="w20 date">
                <div>{props.data.date}</div>
            </div>

            <div className={"row more-info " + (!expand ? "hidden" : "")} onClick={(e) => {e.stopPropagation()}}>
                <div className="row">
                    <div className="w30">
                        <span>Sender account</span><br />
                        AE46778836839821222368
                    </div>
                    <div className="w20">
                        <span>Recipient account</span><br />
                        491990378489487443
                    </div>
                    <div className="w50">
                        <div className="w20">
                            <span>Instructed amount:</span><br />
                            +LYD 100
                        </div>
                        <div className="w20">
                            <span>Transfer amount:</span><br />
                            -LYD 10
                        </div>
                        <div className="w20">
                            <span>Payout fee:</span><br />
                            -LYD 10
                        </div>
                        <div className="w20">
                            <span>Total amount:</span><br />
                            -LYD 20
                        </div>                    
                    </div>
                </div>
                <br />
                <div className="row">
                    <div className="w60">
                        <span>ID:</span>kld0230494-8349-9834-6534-8734837a83-9393939.83748347384 <br />
                        <span>Dynamic payment token:</span>23232320494-8349-9834-6534-8734-949494949596
                    </div> 
                    <div className="w10">
                        <span>Bank code (Swift)</span><br />
                        Ebilaead
                    </div>
                    <div className="w20">
                        <span>Account Number / IBAN</span><br />
                        AE4378678302022SW01
                    </div>
                    <div className="w10">
                        <span>Account Holder Name</span><br />
                        Catering Group LLC
                    </div>                
                </div>

            </div>

            <style jsx>{`
                .transaction-row {
                    padding: 20px;
                    border-bottom: 1px solid #e8e9ec;
                    cursor:pointer;
                }
                .img {
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    float: left;
                    margin-right: 13px;
                }
                .transaction-row > div, .more-info .row > div, .more-info .row > div > div  {
                    display: inline-block;
                    vertical-align: middle;
                }
                .transaction-row:nth-child(odd) {
                    background-color: #fbfcff;
                }
                .user-name {
                    font-weight: 600;
                    font-size: 18px;
                    padding-bottom: 6px;
                }
                .role {
                    font-size: 14px;
                    color: #485573;
                }
                .amount {
                    font-weight: 600;
                    font-size: 16px;
                    color: #33ae3f;
                }
                .amount.error {
                    color: #ff0f00;
                }
                .date {
                    font-size: 16px;
                    text-align: right;
                }
                .hidden {
                    display: none !important;
                }
                .more-info {
                    padding:20px 0 0 54px;
                    font-size:16px;
                    cursor:default;
                }
                .more-info span {
                    color:#9DA6BB;
                }
            `}</style>
        </div>
    );
}
 
export default TransactionRow;