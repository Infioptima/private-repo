import Link from "next/link"
import transactions from "../../stores/transactions"
import TransactionRow from "./TransactionRow"

const TransactionsTable = (props) => {
    return (
        <div className="transactions-table white-box">
            {props.children}
            <div className="row table-head">
                <span className="w30">Sender</span>
                <span className="w30">Receiver</span>
                <span className="w10">Status</span>
                <span className="w10">Payment</span>
                <span className="w20 date">Date</span>
            </div>
            <div className="table">
                {transactions.map((transaction, index) => 
                    <TransactionRow data={transaction} key={transaction.id}></TransactionRow>
                )}
            </div>
            
            <style jsx>{`
                .transactions-table {
                    width: 100%;
                    min-height: 514px;
                    padding: 30px 35px 0 35px;
                }
                h2 {
                    float: left;
                    padding: 0;
                    line-height: 25px;
                }
                .view-all {
                    float: right;
                    margin: 0;
                    font-weight: bold;
                    font-size: 18px;
                    line-height: 22px;
                }
                .table-head {
                    font-weight: 600;
                    font-size: 14px;
                    line-height: 17px;
                    text-transform: uppercase;
                    color: #7e889f;
                    padding: 15px 20px 10px 20px;
                }
                .table-head span {
                    display: inline-block;
                }
                .table {
                    width: 100%;
                    border-top: 1px solid #e8e9ec;
                }
                .date {
                    text-align: right;
                    padding-right: 140px;
                }
            `}</style>
        </div>
    )
}
 
export default TransactionsTable