const TransactionRow = (props) => {
    console.log(props.data)
    return ( 
        <div className="transaction-row row">
            <div className="w30">
                <img src={props.data.sender.icon} className="img" />
                <div className="user-name">{props.data.sender.name}</div>
                <div className="role">{props.data.sender.role}</div>
            </div>
            <div className="w30">
                <img src={props.data.receiver.icon} className="img" />
                <div className="user-name">{props.data.receiver.name}</div>
                <div className="role">{props.data.receiver.role}</div>
            </div>
            <div className="w10">
                <div className="amount">{props.data.amount}</div>
            </div>
            <div className="w30 date">
                <div>{props.data.date}</div>
            </div>

            <style jsx>{`
                .transaction-row {
                    padding:20px;
                    border-bottom: 1px solid #E8E9EC;
                }
                .img {
                    width:40px;
                    height:40px;
                    border-radius:50%; 
                    float:left;
                    margin-right:13px;
                }
                .transaction-row>div {
                    display:inline-block;
                    vertical-align: middle;
                }
                .transaction-row:nth-child(odd) {
                    background-color: #FBFCFF;
                }
                .user-name {
                    font-weight: 600;
                    font-size: 18px;
                    padding-bottom:6px;
                }
                .role {
                    font-size:14px;
                    color: #485573;
                }
                .amount {
                    font-weight: 600;
                    font-size: 16px;
                    color:#33AE3F;
                }

                .amount.error {
                    color:#FF0F00;
                }
                .date {
                    font-size:16px;
                    text-align:right;
                }
            `}</style>
        </div>
    );
}
 
export default TransactionRow;