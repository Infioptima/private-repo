import { AreaChart, Area, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import data from '../../stores/chartData';

const Chart = () => { 
    return (
        <ResponsiveContainer width={"98%"} height={"75%"}>
            <AreaChart data={data} >
                <defs>
                    <linearGradient id="sales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4E83FF" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#fff" stopOpacity={0}/>
                    </linearGradient>
                </defs>
                <Area type="monotone" dataKey="amount" stroke="#004DFF" strokeWidth="2" fillOpacity={1} fill="url(#sales)" />
                <CartesianGrid stroke="#E8E9EC" strokeDasharray="5 5" />
                <XAxis dataKey="name" style={{fontSize: '14px'}}/>
                <YAxis style={{fontSize: '14px'}} />
            </AreaChart>
        </ResponsiveContainer>
    );
}

export default Chart