const ChartFilters = (props) => {
    return (
        <div className="chart-filters">
            <span>1D</span>
            <span className="active">7D</span>
            <span>1M</span>
            <span>3M</span>
            <span>1Y</span>

            <style jsx>{`
                .chart-filters {
                    float:right;
                    margin:30px 35px 0 0;
                }
                .chart-filters span {
                    width:72px;
                    height:30px;
                    line-height:30px;
                    font-weight: bold;
                    font-size: 16px;
                    cursor:pointer;
                    display:inline-block;
                    text-align:center;
                }
                .active {
                    background: #EF7C29;
                    border-radius: 10px;
                    color:white;
                }
            `}</style>
        </div>
    );
};

export default ChartFilters;
