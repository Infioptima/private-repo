const StatBlock = (props) => {
    return ( 
        <div className={"stat-block " + props.class}>
            <div className="color-box"></div>
            <h3>{props.title}</h3>
            <span className="value">{props.value}</span>
            <span className="currency">{props.currency}</span>
            
            <style jsx>{`
                .stat-block {
                    width:100%;
                    height:126px;
                    background: #FFFFFF;
                    box-shadow: 0px 4px 4px #D7DCE8;
                    border-radius: 10px;
                    margin-bottom:20px;
                    overflow:hidden;
                }
                .color-box {
                    width:90px;
                    height:126px;
                    float:left;
                }
                .current-balance .color-box {
                    background: rgba(59, 80, 234, 0.8);
                }
                .available-balance .color-box {
                    background: rgba(0, 154, 15, 0.8);
                }
                .daily-sales .color-box {
                    background: rgba(255, 177, 24, 0.8);
                }
                h3 {
                    font-weight: 600;
                    font-size: 22px;
                    line-height: 26px;
                    letter-spacing: 0.03em;
                    margin:24px 0 8px 120px;
                }
                .value {
                    font-weight: 500;
                    font-size: 36px;
                    line-height: 43px;
                    letter-spacing: 0.03em;
                    padding: 0 10px 0 28px;
                }
                .currency {
                    font-weight: 500;
                    font-size: 18px;
                    line-height: 22px;
                }
            `}</style>
        </div>

        
    );
}
 
export default StatBlock;